# 貓咪疫苗待辦 App - 部署教學（Vercel + Firebase，全部免費）

跟著以下步驟做，完成後會有一個網址，任何人點開就能直接用，**不用登入 Claude、不用付費**。

## 第一步：建立 Firebase 專案（存資料用，免費）

1. 打開 https://console.firebase.google.com ，用 Google 帳號登入
2. 點「新增專案」，取個名字（例如 cat-app），一路下一步（可以關掉 Google Analytics，不需要）
3. 進入專案後，左邊選單點「建構」→「Firestore Database」，點「建立資料庫」
4. 選「以測試模式啟動」（之後我們會改規則），地區選 asia-east1（台灣近）
5. 建好後，點左上角齒輪 ⚙️ →「專案設定」，往下捲到「你的應用程式」，點網頁圖示 `</>` 新增一個網頁應用程式，名字隨便取
6. 會出現一段 `firebaseConfig = {...}` 的程式碼，把裡面 6 個值（apiKey、authDomain、projectId、storageBucket、messagingSenderId、appId）複製起來，等一下要用

7. 回到 Firestore Database → 上面「規則」分頁，把內容整個換成：
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /shared/{doc} {
      allow read, write: if true;
    }
  }
}
```
點「發布」。

> ⚠️ 這個規則是「知道網址的人都能讀寫」，適合朋友間共用，不是給陌生人使用的公開服務。

## 第二步：把 Firebase 設定填進程式碼

打開 `src/firebase.js`，把 `firebaseConfig` 裡的 6 個值換成你剛剛複製的內容。

## 第三步：把程式碼放到 GitHub

1. 打開 https://github.com ，登入或註冊帳號
2. 點右上角「+」→「New repository」，取名字（例如 cat-app），設為 Public 或 Private 都可以，點「Create repository」
3. 進到新專案頁面，點「uploading an existing file」
4. 把這個資料夾裡**全部檔案和資料夾**拖進去上傳（包含 `src` 資料夾），下面點「Commit changes」

## 第四步：用 Vercel 部署

1. 打開 https://vercel.com ，選「Continue with GitHub」用剛剛的帳號登入
2. 點「Add New」→「Project」，選你剛剛建立的 repo，點「Import」
3. Vercel 會自動偵測到這是 Vite 專案，設定都不用改，直接點「Deploy」
4. 等 1-2 分鐘完成後，會拿到一個網址，例如 `cat-app.vercel.app`

完成！把這個網址傳給朋友，大家都能直接打開使用，不用登入任何帳號。

## 之後要改功能怎麼辦？

回來這個 Claude 對話跟我說要改什麼，我改完 `src/App.jsx` 的內容後，你只要：
1. 到 GitHub 那個 repo，把新的 `App.jsx` 內容貼上去覆蓋（點檔案 → 鉛筆圖示編輯 → 貼上 → Commit）
2. Vercel 會自動偵測到更新，幾分鐘內自動重新部署，網址不會變
